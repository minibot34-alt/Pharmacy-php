<center>
<head>
<meta charset="UTF-8">
<title>Ljekarna Jurcan</title>
</head>
<h1>Račun</h1>
<?php
echo "Datum narudžbe:" . date(" d.m.Y") . "<br>";
echo "Vrijeme narudžbe:" . date(" H:i:s") . "<br>";
echo "<br>";
$Andol = $_POST['Andol'];
$Aspirin = $_POST['Aspirin'];
$Vitamin = $_POST['Vitamin'];
$Ukupno = $Andol + $Aspirin + $Vitamin;

$cijenaAndol = 2;
$cijenaAspirin = 3;
$cijenaVitamin = 1.5;

$UkupnaCijena =
    ($Andol * $cijenaAndol) +
    ($Aspirin * $cijenaAspirin) +
    ($Vitamin * $cijenaVitamin);

$Porez = $UkupnaCijena+$UkupnaCijena*0.25;

echo "<strong> Naručili ste $Ukupno lijekova. </strong>"."<br>";
echo "Naručili ste  $Andol andol, $Aspirin aspirin, $Vitamin vitamin."."<br>";  
echo"<br>";
echo "<strong>Ukupna cijena: ". $UkupnaCijena. " €</strong>"."<br>";
echo"<strong> Ukupna cijena + PDV: $Porez €</strong> ";
echo "<br>";

$izbor=$_POST['izbor'];
echo"<br>";

if($izbor=='a')
{
echo "Hvala vam što ste naš redovan kupac.";
}

else
{
echo "Dođite nam opet i hvala što ste baš nas odabrali.";	
}	

?>
</center>