<center>
<body background="cupi2.jpg">
<h1><b>Kod Jurcana</b></h1>
<?php
$pizza = $_POST['pizza'];
$velicina = $_POST['velicina'];
$adresa = $_POST['adresa'];
$prezime = $_POST['prezime'];
$telefon = $_POST['telefon'];

if($velicina=="mala"){
    $cijena=10;
}elseif ($velicina=="velika") {
    $cijena=14;
}else {
    $cijena=0;
}

echo "<div style='font-size: 22px;'>";
echo "Odabrana pizza: <b>$pizza</b><br>";
echo "Veličina: <b>$velicina</b><br>";
echo "Cijena: <b>$cijena €</b><br><br>";
echo "Adresa: <b>$adresa</b><br>";
echo "Prezime: <b>$prezime</b><br>";
echo "Telefon: <b>$telefon</b><br>";
echo "</div>";
?>
</center>