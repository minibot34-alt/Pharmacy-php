<?php
$ime = $_POST['ime'];
$prezime = $_POST['prezime'];

echo "Vaše ime je $ime, a prezivate se $prezime.";
?>