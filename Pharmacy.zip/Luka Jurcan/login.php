<?php
session_start();
include 'db.php';

$username = $_POST['username'];
$password = md5($_POST['password']);

$stmt = $conn->prepare("SELECT id FROM korisnici WHERE username=? AND password=?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($user_id);
    $stmt->fetch();

    $_SESSION['user_id'] = $user_id;
    $_SESSION['username'] = $username;

    header("Location: pizzeria.php");
    exit;

} else {
    echo "Pogrešno korisničko ime ili lozinka!";
}

$stmt->close();
?>