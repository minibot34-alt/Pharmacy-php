<html>
<head>
<meta charset="UTF-8">
<title>Rezultat narudžbe</title>
</head>
<body background="cupi2.jpg">
<center>
<h1 style="color:white;">Pizzeria "Kod Jurcana"</h1>

<?php
session_start();
include 'db.php';

$pizze = $_POST['pizza'];
$velicine = $_POST['velicina'];
$kolicine = $_POST['kolicina'];
$adresa = $_POST['adresa'];
$prezime = $_POST['prezime'];
$telefon = $_POST['telefon'];

$cijene_pizza = [
    'margerita' => 5,
    'capricciosa' => 6,
    'quattro_formaggi' => 7,
    'pepperoni' => 8,
    'vegetariana' => 6
];
$nazivi_pizza = [
    'margerita' => 'Margerita',
    'capricciosa' => 'Capricciosa',
    'quattro_formaggi' => 'Quattro formaggi',
    'pepperoni' => 'Pepperoni',
    'vegetariana' => 'Vegetariana'
];

$nazivi_velicina = [
    'mala' => 'Mala',
    'velika' => 'Velika'
];
$grupirano = [];

for ($i=0; $i<count($pizze); $i++) {
    $key = $pizze[$i] . '_' . $velicine[$i];

    if (!isset($grupirano[$key])) {
        $grupirano[$key] = [
            'pizza' => $pizze[$i],
            'velicina' => $velicine[$i],
            'kolicina' => 0
        ];
    }

    $grupirano[$key]['kolicina'] += intval($kolicine[$i]);
}

$ukupno_sve = 0;

echo "<div style='font-size:22px; color:white;'>";
echo "Adresa: <b>$adresa</b><br>";
echo "Prezime: <b>$prezime</b><br>";
echo "Telefon: <b>$telefon</b><br><br>";
echo "<b>Vaša narudžba:</b><br>";

$ukupna_kolicina = 0;

foreach ($grupirano as $stavka) {
    $ukupna_kolicina += $stavka['kolicina'];
}

$ukupno_gratis = intdiv($ukupna_kolicina, 5);
$ukupno_gratis_original = $ukupno_gratis;
foreach ($grupirano as $stavka) {

    $pizza = $stavka['pizza'];
    $velicina = $stavka['velicina'];
    $kolicina = $stavka['kolicina'];

    $cijena = $cijene_pizza[$pizza];
    $cijena += ($velicina=="mala") ? 5 : 9;

    if ($ukupno_gratis > 0) {
        $gratis = min($kolicina, $ukupno_gratis);
        $ukupno_gratis -= $gratis;
    } else {
        $gratis = 0;
    }

    $zanaplatu = $kolicina - $gratis;
	$kolicina_za_bazu = $zanaplatu;
    $ukupno = $zanaplatu * $cijena;

    $imePizza = $nazivi_pizza[$pizza];
    $imeVelicina = $nazivi_velicina[$velicina];

    echo "$imePizza ($imeVelicina), $kolicina kom - ukupno: $ukupno €<br>";

    $ukupno_sve += $ukupno;

    if(isset($_SESSION['user_id'])) {
        $korisnik_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("INSERT INTO narudzbe (korisnik_id, pizza, velicina, kolicina, ukupno) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issid", $korisnik_id, $pizza, $velicina, $kolicina_za_bazu, $ukupno);
        $stmt->execute();
        $stmt->close();
    }
}
echo "<b>Gratis pizze: $ukupno_gratis_original</b><br>";
echo "<br><b>Ukupno za platiti: $ukupno_sve €</b><br>";

if(isset($_SESSION['user_id'])) {
    $korisnik_id = $_SESSION['user_id'];
    $result = $conn->query("SELECT pizza, velicina, kolicina, ukupno, datum 
                            FROM narudzbe 
                            WHERE korisnik_id=$korisnik_id 
                            ORDER BY datum DESC LIMIT 2");

    echo "<h3 style='color:white;'>Zadnje 2 narudžbe:</h3><ul style='color:white;'>";
    while($row = $result->fetch_assoc()) {
        echo "$pizza ($velicina), {$row['kolicina']} kom — {$row['ukupno']} € <br>";
    }
    echo "</ul>";
}

echo "</div>";
?>
</center>
</body>
</html>