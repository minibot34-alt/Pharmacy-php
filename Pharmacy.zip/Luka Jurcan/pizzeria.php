<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'db.php';
?>
<html>
<head>
<meta charset="UTF-8">
<title>Pizzeria Kod Jurcana</title>
<style>
body {
    background-image: url('cupi.jpg');
    background-size: cover;
    font-family: Arial, sans-serif;
}
h1 {
    color: white;
    text-align: center;
    margin-top: 20px;
}
#loginBtn {
    position: absolute;
    top: 20px;
    right: 20px;
    padding: 10px 20px;
    background-color: orange;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: bold;
}
#loginForm {
    display: none;
    position: absolute;
    top: 60px;
    right: 20px;
    background-color: rgba(0,0,0,0.85);
    padding: 20px;
    border-radius: 10px;
    color: white;
    width: 240px;
}
#loginForm .closeBtn {
    background-color: red;
    color: white;
    border: none;
    font-weight: bold;
    float: right;
    cursor: pointer;
    padding: 2px 8px;
    font-size: 14px;
}
#loginForm input {
    display: block;
    margin: 10px 0;
    padding: 5px;
    width: 100%;
}
#loginForm button[type="submit"] {
    padding: 5px 10px;
    background-color: orange;
    border: none;
    color: white;
    cursor: pointer;
    font-weight: bold;
}
#narudzbe {
    color: white;
    border-collapse: collapse;
    margin: 20px auto;
}
#narudzbe th, #narudzbe td {
    border: 1px solid white;
    padding: 5px 10px;
}
#narudzbe th {
    background-color: rgba(0,0,0,0.6);
}
#narudzbe td {
    background-color: rgba(0,0,0,0.3);
}
#narudzbe button {
    padding: 3px 8px;
    background-color: red;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: bold;
}
#dodajRedBtn {
    padding: 8px 15px;
    background-color: green;
    color: white;
    border: none;
    cursor: pointer;
    font-weight: bold;
    margin-top: 10px;
}
.plus, .minus {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    border: none;
    font-size: 22px;
    font-weight: bold;
    color: white;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}

.plus {
    background-color: #28a745; /* zelena */
}

.minus {
    background-color: #dc3545; /* crvena */
}

.plus:hover, .minus:hover {
    transform: scale(1.1);
}
.faq-container {
    max-width: 600px;
    margin: auto;
    background: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

.faq-question {
    cursor: pointer;
    padding: 15px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: bold;
}

.faq-answer {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.4s ease, padding 0.4s ease;
    padding: 0 15px;
}

.faq-answer.show {
    padding: 15px;
    max-height: 200px; /* prilagodi visini odgovora */
}

.icon {
    font-weight: bold;
    font-size: 18px;
    transition: transform 0.3s ease;
}

.icon.rotate {
    transform: rotate(45deg);
}
</style>
</head>
<body>
<h1>Pizzeria "Kod Jurcana"</h1>
<?php
if(isset($_SESSION['username'])){
    echo "<div style='color:white;text-align:center;'>Pozdrav, " . $_SESSION['username'] . "</div>";
}
?>
<button id="loginBtn" onclick="toggleLogin()">Prijava</button>
<div id="loginForm">
  <button class="closeBtn" onclick="zatvoriLogin()">×</button>
  <form method="POST" action="login.php" style="margin-top:20px;">
    <label>Korisničko ime:</label>
    <input type="text" name="username" required>
    <label>Lozinka:</label>
    <input type="password" name="password" required>
    <button type="submit">Prijavi se</button>
  </form>
</div>

<form method="POST" action="obradi2.php" id="narudzbaForm">
  <table id="narudzbe">
    <tr>
      <th>Pizza</th>
      <th>Veličina</th>
      <th>Količina</th>
      <th></th>
    </tr>
    <tr>
      <td>
        <select name="pizza[]">
          <option value="margerita">Margerita</option>
          <option value="capricciosa">Capricciosa</option>
          <option value="quattro_formaggi">Quattro Formaggi</option>
          <option value="pepperoni">Pepperoni</option>
          <option value="vegetariana">Vegetariana</option>
        </select>
      </td>
      <td>
        <select name="velicina[]">
          <option value="mala">Mala (25cm)</option>
          <option value="velika">Velika (35cm)</option>
        </select>
      </td>
      <td>
        <input type="number" name="kolicina[]" value="1" min="1">
      </td>
      <td>
        <button class="minus" type="button" onclick="ukloniRed(this)">−</button>
      </td>
    </tr>
  </table>
  <center>
  <button class="plus" type="button" id="dodajRedBtn" onclick="dodajRed()">+</button>
  <p style="color:white; margin-top:20px;">
    Adresa:<br>
    <input type="text" name="adresa" required><br><br>
    Prezime:<br>
    <input type="text" name="prezime" required><br><br>
    Broj telefona:<br>
    <input type="tel" name="telefon" required><br><br>
  </p>
  <input type="submit" value="Pošalji narudžbu" style="padding:10px 20px; font-weight:bold; cursor:pointer;">
</form>
<br>
<br>
<div class="faq-container">
    <div class="faq-item">
        <div class="faq-question">Koliko vremena traje dostava? <span class="icon">+</span></div>
        <div class="faq-answer">Prosječno 30–45 minuta, ovisno o udaljenosti i gužvi u restoranu.</div>
    </div>
    <div class="faq-item">
        <div class="faq-question">Prihvaćate li kartice ili samo gotovinu? <span class="icon">+</span></div>
        <div class="faq-answer">Prihvaćamo sve kartice i gotovinu.</div>
    </div>
    <div class="faq-item">
        <div class="faq-question">Kako mogu naručiti pizzu? <span class="icon">+</span></div>
        <div class="faq-answer">Možete preko ove web stranice ili putem poziva na naš broj.</div>
    </div>
</div>

</center>

<script>
function toggleLogin() {
    let form = document.getElementById("loginForm");
    form.style.display = (form.style.display === "none" || form.style.display === "") ? "block" : "none";
}
function zatvoriLogin() {
    document.getElementById("loginForm").style.display = "none";
}
function dodajRed() {
    let table = document.getElementById("narudzbe");
    let row = table.insertRow();
    row.innerHTML = `
        <td>
          <select name="pizza[]">
            <option value="margerita">Margerita</option>
            <option value="capricciosa">Capricciosa</option>
            <option value="quattro_formaggi">Quattro Formaggi</option>
            <option value="pepperoni">Pepperoni</option>
            <option value="vegetariana">Vegetariana</option>
          </select>
        </td>
        <td>
          <select name="velicina[]">
            <option value="mala">Mala (25cm)</option>
            <option value="velika">Velika (35cm)</option>
          </select>
        </td>
        <td>
          <input type="number" name="kolicina[]" value="1" min="1">
        </td>
        <td>
          <button class="minus" type="button" onclick="ukloniRed(this)">−</button>
        </td>
    `;
}
function ukloniRed(button) {
    let row = button.parentNode.parentNode;
    row.parentNode.removeChild(row);
}
const questions = document.querySelectorAll(".faq-question");

questions.forEach(q => {
    q.addEventListener("click", () => {
        const answer = q.nextElementSibling;
        const icon = q.querySelector(".icon");
        
      
        answer.classList.toggle("show");
        
        icon.classList.toggle("rotate");
        
        questions.forEach(otherQ => {
            if(otherQ !== q) {
                otherQ.nextElementSibling.classList.remove("show");
                otherQ.querySelector(".icon").classList.remove("rotate");
            }
        });
    });
});
</script>
<?php
if(isset($_SESSION['user_id'])) {

    $korisnik_id = intval($_SESSION['user_id']);

    $sql = "
        SELECT pizza, velicina, kolicina, ukupno, datum
        FROM narudzbe
        WHERE korisnik_id = $korisnik_id
        ORDER BY datum DESC
        LIMIT 2
    ";

    if($result = $conn->query($sql)) {

        echo "<div style='color:white; margin-top:30px; font-size:18px; text-align:center;'>";
        echo "<b>Zadnje 2 narudžbe:</b><br>";

        if($result->num_rows == 0){
            echo "Nema prethodnih narudžbi.";
        }
		$nazivi_pizza = [
    "margerita" => "Margerita",
    "capricciosa" => "Capricciosa",
    "quattro_formaggi" => "Quattro Formaggi",
    "pepperoni" => "Pepperoni",
    "vegetariana" => "Vegetariana"
];

$nazivi_velicina = [
    "mala" => "Mala",
    "velika" => "Velika"
];
        while($row = $result->fetch_assoc()) {

    $pizza = $nazivi_pizza[$row['pizza']] ?? $row['pizza'];
    $velicina = $nazivi_velicina[$row['velicina']] ?? $row['velicina'];

    echo "$pizza ($velicina), {$row['kolicina']} kom — {$row['ukupno']} € <br>";
}

        echo "</div>";

    } else {
        echo "<div style='color:red;text-align:center;'>Greška u upitu.</div>";
    }
}
?>
</body>
</html>