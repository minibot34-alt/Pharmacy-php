<html>
<head>
<meta charset="UTF-8">
<title>Ljekarna Jurcan</title>
</head>
<body>
<center>
<h1>Račun</h1>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

echo "Datum narudžbe: " . date("d.m.Y") . "<br>";
echo "Vrijeme narudžbe: " . date("H:i:s") . "<br><br>";

$Andol = (int)$_POST['Andol'];
$Aspirin = (int)$_POST['Aspirin'];
$Vitamin = (int)$_POST['Vitamin'];

$Ukupno = $Andol + $Aspirin + $Vitamin;

$cijenaAndol = 2;
$cijenaAspirin = 3;
$cijenaVitamin = 1.5;

$UkupnaCijena =
    ($Andol * $cijenaAndol) +
    ($Aspirin * $cijenaAspirin) +
    ($Vitamin * $cijenaVitamin);

$Porez = $UkupnaCijena + $UkupnaCijena * 0.25;

echo "<strong>Naručili ste $Ukupno lijekova.</strong><br>";
echo "Naručili ste $Andol Andol, $Aspirin Aspirin, $Vitamin Vitamin.<br><br>";

echo "<strong>Ukupna cijena: $UkupnaCijena €</strong><br>";
echo "<strong>Ukupna cijena + PDV: $Porez €</strong><br><br>";

$izbor = $_POST['izbor'];

if ($izbor == 'a') {
    echo "Hvala vam što ste naš redovan kupac.<br><br>";
} else {
    echo "Dođite nam opet i hvala što ste baš nas odabrali.<br><br>";
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ljekarna";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Greška pri povezivanju: " . $conn->connect_error);
}

$naziv = "Panadol";
$cijena = 8.50;
$kolicina = 120;

$stmt = $conn->prepare("INSERT INTO lijekovi (naziv, cijena, kolicina, datum_dodavanja) VALUES (?, ?, ?, NOW())");
$stmt->bind_param("sdi", $naziv, $cijena, $kolicina);

if ($stmt->execute()) {
    echo "Novi lijek je uspješno dodan!<br><br>";
} else {
    echo "Greška pri dodavanju: " . $stmt->error . "<br><br>";
}

$stmt->close();

$sql = "SELECT id, naziv, cijena, kolicina, datum_dodavanja FROM lijekovi";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] .
             " - Naziv: " . $row["naziv"] .
             " - Cijena: " . $row["cijena"] . " €" .
             " - Količina: " . $row["kolicina"] .
             " - Datum dodavanja: " . $row["datum_dodavanja"] .
             "<br>";
    }
} else {
    echo "Nema podataka u bazi.";
}

$conn->close();

} else {
    echo "Molimo popunite formu za narudžbu.";
}

?>

</center>
</body>
</html>
